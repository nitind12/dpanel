<div class="col-sm-12">
	&nbsp;
</div>
<div class="col-sm-12">
	<p style="text-align: justify">
		This panel is just the initiation of making portal more dynamic. So that we all can update various ventures at our own end by providing secure User Identifications. 
		This makes the availablility of presenting data on website on-time whenever needed. No need to wait to transfer the significant data via long channels.
	</p>
	<p>
		We starts this initiation with [News &amp; Activities, Gallery, Birthday].
	</p>
	<p>
		You can also participate by your most valuable suggestions to make this portal more user-friendly and effective through e-mail provided below.<br />
	</p>
	<p>
		Email your suggestions, feedback &amp; problems at: <span style="color: #0000ff">ttchld@gmail.com</span>
	</p>
	<p>
		Hoping positive cooperation.
	</p>
	<p style="padding: 25px">
	</p>
	<p>
		Thanks &amp; Regards,
	</p>
	<p>
		Technical Team,<br />
		Teamfreelancers
	</p>
</div>