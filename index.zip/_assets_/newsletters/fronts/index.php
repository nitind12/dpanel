<?php
	session_start();
	session_destroy();
	header('http://www.amrapali.ac.in');
?>